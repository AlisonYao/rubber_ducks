console.log("js working");

function sitdown(){
    document.getElementById("image").style.backgroundColor="yellow";
    console.log("!!!");
}
